<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../config/config.php'; // Pastikan path ini sesuai dengan lokasi file config.php

session_start();

// Cek jika form login disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        // Query untuk mendapatkan user berdasarkan username
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Login berhasil
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Redirect berdasarkan role
            if ($user['role'] == 'admin') {
                header('Location: /admin/dashboard.php');
            } else {
                header('Location: /user/dashboard.php');
            }
            exit;
        } else {
            // Jika username atau password salah
            $error = "Username atau Password salah!";
        }
    } catch (PDOException $e) {
        // Tangani kesalahan database
        $error = "Database error: " . $e->getMessage();
    }
}
?>

<!-- Form Login -->
<form action="proses_login.php" method="POST">
    <input type="email" name="email" required placeholder="Email">
    <input type="password" name="password" required placeholder="Password">
    <button type="submit">Login</button>
</form>


<?php if (isset($error)) echo "<p>$error</p>"; ?>
