<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'user'; // Default role

    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $stmt->execute([$username, $password, $role]);

        header("Location: login.php");
        exit;
    } catch (PDOException $e) {
        echo "Gagal mendaftar: " . $e->getMessage();
    }
}
?>

<!-- Form pendaftaran -->
<form method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Daftar</button>
</form>
