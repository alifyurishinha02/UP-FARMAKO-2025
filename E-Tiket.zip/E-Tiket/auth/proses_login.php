<?php
session_start();
require_once 'config/config.php'; // Pastikan file koneksi ke DB

// Ambil data dari form
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Query user berdasarkan email
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {
    // Set session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['email'] = $user['email'];

    // Redirect sesuai role
    if ($user['role'] == 'admin') {
        header('Location: ../dashborad/admin/dashbord.php');
    } else {
        header('Location: ../dashborad/user/dashbord.php');
    }
    exit;
} else {
    echo "Login gagal. Email atau password salah.";
}
