<?php
require_once 'Database.php';

class Produk extends Database {
    public function getAll() {
        $query = "SELECT * FROM produk";
        return $this->conn->query($query);
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM produk WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function create($jenis, $asal, $tujuan, $tanggal, $harga) {
        $stmt = $this->conn->prepare("INSERT INTO produk (jenis_transportasi, rute_asal, rute_tujuan, tanggal, harga) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssd", $jenis, $asal, $tujuan, $tanggal, $harga);
        return $stmt->execute();
    }

    public function update($id, $jenis, $asal, $tujuan, $tanggal, $harga) {
        $stmt = $this->conn->prepare("UPDATE produk SET jenis_transportasi=?, rute_asal=?, rute_tujuan=?, tanggal=?, harga=? WHERE id=?");
        $stmt->bind_param("ssssdi", $jenis, $asal, $tujuan, $tanggal, $harga, $id);
        return $stmt->execute();
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM produk WHERE id=?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>
