<?php
require_once 'Database.php';

class Pemesanan extends Database {
    public function pesan($user_id, $produk_id) {
        $stmt = $this->conn->prepare("INSERT INTO pemesanan (user_id, produk_id, status) VALUES (?, ?, 'pending')");
        $stmt->bind_param("ii", $user_id, $produk_id);
        return $stmt->execute();
    }

    public function getRiwayat($user_id) {
        $stmt = $this->conn->prepare("
            SELECT p.*, pr.jenis_transportasi, pr.rute_asal, pr.rute_tujuan, pr.tanggal, pr.harga
            FROM pemesanan p
            JOIN produk pr ON p.produk_id = pr.id
            WHERE p.user_id = ?
            ORDER BY p.created_at DESC
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result();
    }
}
?>
