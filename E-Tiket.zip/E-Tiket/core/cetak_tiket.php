<?php
require 'vendor/autoload.php'; // autoload composer
use Dompdf\Dompdf;
use Dompdf\Options;

session_start();
require_once 'config/database.php'; // sesuaikan dengan lokasi koneksi DB kamu

// Cek login dan pastikan user adalah pelanggan
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    die("Akses ditolak.");
}

// Ambil ID pemesanan dari URL
if (!isset($_GET['id'])) {
    die("ID pemesanan tidak ditemukan.");
}

$pemesanan_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Ambil data pemesanan
$stmt = $pdo->prepare("SELECT p.*, u.nama, pr.nama_produk, pr.jenis, pr.rute, pr.harga 
                       FROM pemesanan p 
                       JOIN users u ON p.user_id = u.id 
                       JOIN produk pr ON p.produk_id = pr.id 
                       WHERE p.id = ? AND p.user_id = ?");
$stmt->execute([$pemesanan_id, $user_id]);
$data = $stmt->fetch();

if (!$data) {
    die("Data tidak ditemukan.");
}

// HTML untuk tiket
$html = '
    <h2 style="text-align:center;">E-Tiket Transportasi</h2>
    <hr>
    <p><strong>Nama:</strong> ' . $data['nama'] . '</p>
    <p><strong>Tipe:</strong> ' . ucfirst($data['jenis']) . '</p>
    <p><strong>Rute:</strong> ' . $data['rute'] . '</p>
    <p><strong>Harga:</strong> Rp ' . number_format($data['harga']) . '</p>
    <p><strong>Status:</strong> ' . $data['status'] . '</p>
    <p><strong>Tanggal Pemesanan:</strong> ' . $data['tanggal_pesan'] . '</p>
    <hr>
    <p style="text-align:center;">Harap tunjukkan tiket ini saat perjalanan</p>
';

// Inisialisasi dompdf
$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);

// Atur ukuran dan orientasi
$dompdf->setPaper('A4', 'portrait');

// Render PDF
$dompdf->render();

// Output ke browser
$dompdf->stream("tiket-" . $data['id'] . ".pdf", ["Attachment" => false]);
exit;
