<?php
session_start();
if (isset($_SESSION['user_id'])) {
    // Redirect jika sudah login
    if ($_SESSION['role'] == 'admin') {
        header('Location: dashboard/admin/dashbord.php');
    } else {
        header('Location: dashboard/user/dashbord.php');
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Selamat Datang di E-Tiket</title>
    <style>
        body {
            font-family: sans-serif;
            background: #f0f2f5;
            padding: 40px;
            text-align: center;
        }
        .container {
            background: white;
            padding: 40px;
            max-width: 600px;
            margin: 0 auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 { color: #007BFF; }
        a.button {
            display: inline-block;
            margin: 10px;
            padding: 10px 30px;
            background: #007BFF;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        a.button:hover {
            background: #0056b3;
        }
        .footer {
            margin-top: 40px;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Selamat Datang di E-Tiket</h1>
    <p>Beli tiket kereta, pesawat, dan bus dengan mudah, cepat, dan aman!</p>

    <a href="auth/login.php" class="button">Login</a>
    <a href="auth/register.php" class="button">Daftar</a>
</div>

<div class="footer">
    &copy; <?= date('Y') ?> E-Tiket | Created by Andrean 😄
</div>

</body>
</html>
