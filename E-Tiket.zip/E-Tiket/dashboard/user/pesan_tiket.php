<?php
require_once '../../core/Auth.php';
require_once '../../core/Pemesanan.php';
Auth::check();

if (!Auth::isUser()) exit("Akses ditolak");

$pemesanan = new Pemesanan();
$produk_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

$pemesanan->pesan($user_id, $produk_id);
echo "Tiket berhasil dipesan!";
echo "<br><a href='riwayat_pemesanan.php'>Lihat Riwayat</a>";
