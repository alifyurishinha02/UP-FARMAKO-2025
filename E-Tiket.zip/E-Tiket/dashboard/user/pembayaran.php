<?php
require_once '../../core/Auth.php';
require_once '../../core/Pemesanan.php';
Auth::check();

if (!Auth::isUser()) exit("Akses ditolak");

$pemesanan = new Pemesanan();
$riwayat = $pemesanan->getRiwayat($_SESSION['user_id']);

// Menampilkan pemesanan yang statusnya 'pending'
$pendingOrders = [];
while ($r = $riwayat->fetch_assoc()) {
    if ($r['status'] == 'pending') {
        $pendingOrders[] = $r;
    }
}
?>

<h2>Pembayaran Tiket</h2>

<?php if (count($pendingOrders) > 0): ?>
    <table border="1" cellpadding="6">
        <tr>
            <th>Jenis</th><th>Asal</th><th>Tujuan</th><th>Tanggal</th><th>Harga</th><th>Aksi</th>
        </tr>
        <?php foreach ($pendingOrders as $order): ?>
        <tr>
            <td><?= $order['jenis_transportasi'] ?></td>
            <td><?= $order['rute_asal'] ?></td>
            <td><?= $order['rute_tujuan'] ?></td>
            <td><?= $order['tanggal'] ?></td>
            <td>Rp<?= number_format($order['harga'], 0, ',', '.') ?></td>
            <td>
                <a href="bayar_tiket.php?id=<?= $order['id'] ?>">Bayar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
<?php else: ?>
    <p>Anda tidak memiliki pemesanan yang belum dibayar.</p>
<?php endif; ?>
