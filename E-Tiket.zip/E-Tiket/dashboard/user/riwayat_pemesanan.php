<?php
require_once '../../core/Auth.php';
require_once '../../core/Pemesanan.php';
Auth::check();

if (!Auth::isUser()) exit("Akses ditolak");

$pemesanan = new Pemesanan();
$riwayat = $pemesanan->getRiwayat($_SESSION['user_id']);
?>

<h2>Riwayat Pemesanan</h2>
<table border="1" cellpadding="6">
    <tr>
        <th>Jenis</th><th>Asal</th><th>Tujuan</th><th>Tanggal</th><th>Harga</th><th>Status</th><th>Aksi</th>
    </tr>
    <?php while ($r = $riwayat->fetch_assoc()): ?>
    <tr>
        <td><?= $r['jenis_transportasi'] ?></td>
        <td><?= $r['rute_asal'] ?></td>
        <td><?= $r['rute_tujuan'] ?></td>
        <td><?= $r['tanggal'] ?></td>
        <td>Rp<?= number_format($r['harga'], 0, ',', '.') ?></td>
        <td><?= ucfirst($r['status']) ?></td>
        <td>
            <?php if ($r['status'] == 'dibayar'): ?>
                <!-- Tampilkan tombol Cetak Tiket jika status "dibayar" -->
                <a href="../../cetak_tiket.php?id=<?= $r['id'] ?>" target="_blank">Cetak Tiket</a>
            <?php else: ?>
                -
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
