<?php
session_start();

// Cek apakah sudah login dan apakah role-nya user
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'user') {
    header('Location: ../auth/login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User</title>
</head>
<body>
    <h2>Selamat datang, <?= $_SESSION['username'] ?>!</h2>
    <nav>
        <ul>
            <li><a href="riwayat_pemesanan.php">Riwayat Pemesanan</a></li>
            <li><a href="status_pemesanan.php">Status Pemesanan</a></li>
            <li><a href="../../auth/logout.php">Logout</a></li>
        </ul>
    </nav>
</body>
</html>
