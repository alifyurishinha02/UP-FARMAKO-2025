<?php
require_once '../../core/Auth.php';
require_once '../../core/Produk.php';
Auth::check();

if (!Auth::isUser()) exit("Akses ditolak");

$produk = new Produk();
$keyword = $_GET['keyword'] ?? '';
$tanggal = $_GET['tanggal'] ?? '';

$where = "1=1";
if ($keyword) $where .= " AND (rute_asal LIKE '%$keyword%' OR rute_tujuan LIKE '%$keyword%')";
if ($tanggal) $where .= " AND tanggal = '$tanggal'";

$result = $produk->conn->query("SELECT * FROM produk WHERE $where ORDER BY tanggal ASC");
?>

<h2>Cari Tiket</h2>
<form method="get">
    Rute (Asal/Tujuan): <input type="text" name="keyword" value="<?= $keyword ?>">
    Tanggal: <input type="date" name="tanggal" value="<?= $tanggal ?>">
    <button type="submit">Cari</button>
</form>

<table border="1" cellpadding="6">
    <tr>
        <th>Jenis</th><th>Asal</th><th>Tujuan</th><th>Tanggal</th><th>Harga</th><th>Aksi</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['jenis_transportasi'] ?></td>
        <td><?= $row['rute_asal'] ?></td>
        <td><?= $row['rute_tujuan'] ?></td>
        <td><?= $row['tanggal'] ?></td>
        <td>Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
        <td><a href="pesan_tiket.php?id=<?= $row['id'] ?>">Pesan</a></td>
    </tr>
    <?php endwhile; ?>
</table>
