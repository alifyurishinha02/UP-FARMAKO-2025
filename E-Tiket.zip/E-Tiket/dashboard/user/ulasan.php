<?php
require_once '../../core/Auth.php';
require_once '../../core/Database.php';
Auth::check();

if (!Auth::isUser()) exit("Akses ditolak");

$db = Database::getInstance()->getConnection();

// Ambil daftar produk yang sudah dibayar dan belum diulas
$user_id = $_SESSION['user_id'];
$data = $db->query("
    SELECT p.id as produk_id, p.jenis_transportasi, p.rute_asal, p.rute_tujuan
    FROM pemesanan pm
    JOIN produk p ON p.id = pm.produk_id
    WHERE pm.user_id = $user_id AND pm.status = 'dibayar'
    AND NOT EXISTS (
        SELECT 1 FROM ulasan u WHERE u.produk_id = p.id AND u.user_id = $user_id
    )
");
?>

<h2>Beri Ulasan</h2>

<?php while($r = $data->fetch_assoc()): ?>
<form action="ulasan.php" method="POST">
    <input type="hidden" name="produk_id" value="<?= $r['produk_id'] ?>">
    <p><strong><?= $r['jenis_transportasi'] ?>: <?= $r['rute_asal'] ?> - <?= $r['rute_tujuan'] ?></strong></p>
    Rating:
    <select name="rating">
        <?php for ($i=1; $i<=5; $i++) echo "<option value='$i'>$i</option>"; ?>
    </select><br>
    Komentar:<br>
    <textarea name="komentar" rows="3" cols="40" required></textarea><br>
    <button type="submit">Kirim Ulasan</button>
</form>
<hr>
<?php endwhile; ?>

<?php
// Proses kirim ulasan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produk_id = $_POST['produk_id'];
    $rating = $_POST['rating'];
    $komentar = $db->real_escape_string($_POST['komentar']);

    $stmt = $db->prepare("INSERT INTO ulasan (user_id, produk_id, rating, komentar) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $user_id, $produk_id, $rating, $komentar);
    $stmt->execute();

    echo "<p>✅ Ulasan berhasil dikirim!</p>";
    echo "<meta http-equiv='refresh' content='1'>";
}
?>
