<?php
require_once '../../core/Auth.php';
require_once '../../core/Pemesanan.php';
Auth::check();

if (!Auth::isUser()) exit("Akses ditolak");

$pemesanan = new Pemesanan();
$id = $_GET['id'];

// Mengupdate status pemesanan menjadi 'dibayar'
$stmt = $pemesanan->conn->prepare("UPDATE pemesanan SET status='dibayar' WHERE id=? AND user_id=?");
$stmt->bind_param("ii", $id, $_SESSION['user_id']);
$stmt->execute();

echo "Pembayaran berhasil dilakukan! Tiket Anda telah dibayar.";
echo "<br><a href='riwayat_pemesanan.php'>Lihat Riwayat Pemesanan</a>";
