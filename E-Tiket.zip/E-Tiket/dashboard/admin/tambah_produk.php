<?php
require_once '../../core/Auth.php';
require_once '../../core/Produk.php';
Auth::check();

if (!Auth::isAdmin()) exit("Akses ditolak");

$produk = new Produk();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produk->create($_POST['jenis'], $_POST['asal'], $_POST['tujuan'], $_POST['tanggal'], $_POST['harga']);
    header("Location: produk.php");
}
?>

<h2>Tambah Produk Transportasi</h2>
<form method="post">
    Jenis:
    <select name="jenis">
        <option value="pesawat">Pesawat</option>
        <option value="kereta">Kereta</option>
        <option value="bus">Bus</option>
    </select><br>
    Asal: <input type="text" name="asal"><br>
    Tujuan: <input type="text" name="tujuan"><br>
    Tanggal: <input type="date" name="tanggal"><br>
    Harga: <input type="number" name="harga"><br>
    <button type="submit">Simpan</button>
</form>
