<?php
require_once '../../core/Auth.php';
require_once '../../core/Produk.php';
Auth::check();

if (!Auth::isAdmin()) exit("Akses ditolak");

$produk = new Produk();
$data = $produk->getAll();
?>

<h2>Manajemen Produk Transportasi</h2>
<a href="tambah_produk.php">+ Tambah Produk</a>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th><th>Jenis</th><th>Asal</th><th>Tujuan</th><th>Tanggal</th><th>Harga</th><th>Aksi</th>
    </tr>
    <?php while ($row = $data->fetch_assoc()) : ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= ucfirst($row['jenis_transportasi']) ?></td>
        <td><?= $row['rute_asal'] ?></td>
        <td><?= $row['rute_tujuan'] ?></td>
        <td><?= $row['tanggal'] ?></td>
        <td>Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
        <td>
            <a href="edit_produk.php?id=<?= $row['id'] ?>">Edit</a> |
            <a href="hapus_produk.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin?')">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
