<?php
require_once '../../core/Auth.php';
require_once '../../core/Database.php';
Auth::check();

if (!Auth::isAdmin()) exit("Akses ditolak");

$db = Database::getInstance()->getConnection();


// Jumlah pengguna
$jmlPengguna = $db->query("SELECT COUNT(*) as total FROM users WHERE role='user'")->fetch_assoc()['total'];

// Jumlah transaksi (pemesanan)
$jmlTransaksi = $db->query("SELECT COUNT(*) as total FROM pemesanan")->fetch_assoc()['total'];

// Jumlah pemesanan yang dibayar
$jmlDibayar = $db->query("SELECT COUNT(*) as total FROM pemesanan WHERE status='dibayar'")->fetch_assoc()['total'];

// Total pendapatan
$totalPendapatan = $db->query("
    SELECT SUM(p.harga) as total 
    FROM pemesanan pm 
    JOIN produk p ON p.id = pm.produk_id 
    WHERE pm.status='dibayar'
")->fetch_assoc()['total'];

?>

<h2>Laporan Ringkasan</h2>
<ul>
    <li>Total Pengguna: <?= $jmlPengguna ?></li>
    <li>Total Transaksi: <?= $jmlTransaksi ?></li>
    <li>Pemesanan Dibayar: <?= $jmlDibayar ?></li>
    <li>Total Pendapatan: Rp<?= number_format($totalPendapatan ?? 0, 0, ',', '.') ?></li>
</ul>

<hr>
<h3>Daftar Transaksi</h3>
<table border="1" cellpadding="6">
    <tr>
        <th>User</th><th>Transportasi</th><th>Asal</th><th>Tujuan</th><th>Tanggal</th><th>Status</th><th>Harga</th>
    </tr>
    <?php
    $data = $db->query("
        SELECT u.username, p.jenis_transportasi, p.rute_asal, p.rute_tujuan, p.tanggal, pm.status, p.harga
        FROM pemesanan pm
        JOIN users u ON u.id = pm.user_id
        JOIN produk p ON p.id = pm.produk_id
        ORDER BY pm.created_at DESC
    ");
    while ($row = $data->fetch_assoc()):
    ?>
    <tr>
        <td><?= $row['username'] ?></td>
        <td><?= $row['jenis_transportasi'] ?></td>
        <td><?= $row['rute_asal'] ?></td>
        <td><?= $row['rute_tujuan'] ?></td>
        <td><?= $row['tanggal'] ?></td>
        <td><?= ucfirst($row['status']) ?></td>
        <td>Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
    </tr>
    <?php endwhile; ?>
</table>
