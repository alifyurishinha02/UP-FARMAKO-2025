<?php
require_once '../../core/Auth.php';
require_once '../../core/Produk.php';
Auth::check();

if (!Auth::isAdmin()) exit("Akses ditolak");

$produk = new Produk();
$produk->delete($_GET['id']);
header("Location: produk.php");
