<?php
require_once '../../core/Auth.php';
require_once '../../core/Produk.php';
Auth::check();

if (!Auth::isAdmin()) exit("Akses ditolak");

$produk = new Produk();
$id = $_GET['id'];
$data = $produk->getById($id);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produk->update($id, $_POST['jenis'], $_POST['asal'], $_POST['tujuan'], $_POST['tanggal'], $_POST['harga']);
    header("Location: produk.php");
}
?>

<h2>Edit Produk</h2>
<form method="post">
    Jenis:
    <select name="jenis">
        <option value="pesawat" <?= $data['jenis_transportasi'] == 'pesawat' ? 'selected' : '' ?>>Pesawat</option>
        <option value="kereta" <?= $data['jenis_transportasi'] == 'kereta' ? 'selected' : '' ?>>Kereta</option>
        <option value="bus" <?= $data['jenis_transportasi'] == 'bus' ? 'selected' : '' ?>>Bus</option>
    </select><br>
    Asal: <input type="text" name="asal" value="<?= $data['rute_asal'] ?>"><br>
    Tujuan: <input type="text" name="tujuan" value="<?= $data['rute_tujuan'] ?>"><br>
    Tanggal: <input type="date" name="tanggal" value="<?= $data['tanggal'] ?>"><br>
    Harga: <input type="number" name="harga" value="<?= $data['harga'] ?>"><br>
    <button type="submit">Update</button>
</form>
