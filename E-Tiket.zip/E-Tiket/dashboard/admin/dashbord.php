<?php
session_start();

// Cek apakah sudah login dan apakah role-nya admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
</head>
<body>
    <h2>Selamat datang, Admin!</h2>
    <nav>
        <ul>
            <li><a href="manajemen_pengguna.php">Manajemen Pengguna</a></li>
            <li><a href="manajemen_produk.php">Manajemen Produk</a></li>
            <li><a href="laporan.php">Laporan</a></li>
            <li><a href="ulasan.php">Ulasan Pengguna</a></li>
            <li><a href="../auth/logout.php">Logout</a></li>
        </ul>
    </nav>
</body>
</html>
