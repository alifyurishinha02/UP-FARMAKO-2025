<?php
require_once '../../core/Auth.php';
require_once '../../core/Database.php';
Auth::check();

if (!Auth::isAdmin()) exit("Akses ditolak");

$db = Database::getInstance()->getConnection();
$data = $db->query("
    SELECT u.username, p.jenis_transportasi, p.rute_asal, p.rute_tujuan, ul.rating, ul.komentar, ul.created_at
    FROM ulasan ul
    JOIN users u ON ul.user_id = u.id
    JOIN produk p ON ul.produk_id = p.id
    ORDER BY ul.created_at DESC
");
?>

<h2>Ulasan Pengguna</h2>
<table border="1" cellpadding="6">
    <tr>
        <th>Pengguna</th><th>Transportasi</th><th>Rute</th><th>Rating</th><th>Komentar</th><th>Tanggal</th>
    </tr>
    <?php while($r = $data->fetch_assoc()): ?>
    <tr>
        <td><?= $r['username'] ?></td>
        <td><?= $r['jenis_transportasi'] ?></td>
        <td><?= $r['rute_asal'] ?> - <?= $r['rute_tujuan'] ?></td>
        <td><?= $r['rating'] ?>/5</td>
        <td><?= $r['komentar'] ?></td>
        <td><?= $r['created_at'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>
