<?php
require_once '../core/Auth.php';
Auth::check();

if (!Auth::isAdmin()) {
    echo "Akses ditolak. Halaman ini hanya untuk admin.";
    exit;
}
?>

<h2>Selamat datang di Dashboard Admin</h2>
<a href="../logout.php">Logout</a>
