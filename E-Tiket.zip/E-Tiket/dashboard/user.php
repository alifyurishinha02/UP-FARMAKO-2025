<?php
require_once '../core/Auth.php';
Auth::check();

if (!Auth::isUser()) {
    echo "Akses ditolak. Halaman ini hanya untuk pengguna.";
    exit;
}
?>

<h2>Selamat datang di Dashboard Pengguna</h2>
<a href="../logout.php">Logout</a>
